# 当前状态

更新：2026-09-27。

## N02规则借鉴与入口盘点（2026-09-27）

- 根AGENTS补齐用户问题/字母选项编号、OBJ/SURF编号[Comment]、写入备份门禁、Run短路径入口和分层发现；产品光学指令同步，运行中DSH加载未重启验证。
- 新增docs/governance/agent-discovery.md与zemax-write-gates.md；按现有实现区分只读、副本、显式保存与未来原位修改。保留现有run/backup磁盘备份，不照搬N02先Save dirty的副作用；集中备份保留5份/自动回收尚未实现，已明确边界。
- 建立.experience轻量索引和已实测源光线数pickup经验；经验链接进入项目检查。项目Skill仍用原生目录发现，没有虚设N02技能版本注册表、STUDYS结构或子Agent默认委派。
- 公共报告新增对象标签函数，Rx控制/源/探测面/pickup及图表标题组合备注；通用Tx Setup缺历史备注标comment未记录，明确区别空备注。3项标签/转义、5项run包、16项Rx及13项保存回归共37项通过，项目检查通过。
- 已将旧Rx结果重新排版为runs/rx-report/260927-01，记录原manifest哈希和源结果；没有重新追迹、原run未改。Tabbit 1440/390验证全表格左对齐、完整备注和无整页溢出，截图已查看；固定合成模板同步。新报告清单核验通过。


## 报告表格统一左对齐（2026-09-27）

- 按用户要求，报告规范明确表头、行标题及全部数据（含数字/百分比）统一左对齐；公共CSS移除后续表头列右对齐规则，数字单元格也改左对齐，固定HTML样例同步。
- 新生成报告遵循此规则。历史run报告已内嵌旧CSS，按证据不可覆盖规范保持原样。项目链接检查通过；本次为样式与规范调整，未重新追迹。


## Rx FOV实例2真实扫描（2026-09-27，已实测）

- 用户授权在实例2当前`optdsh-test-2.zmx`测试且不调用GLM；只读检查92对象，重新确认H18/V82、pickup81、回波源85及转镜31/Rx入口55/SPAD63。主模型原为Tx源2/3各20万条、回波源0条，默认Skill预检正确阻塞。
- 用户检查后确认仅副本关闭Tx2/3、启用回波85十万条且保留0.0001 W；H=-10/0/+10°、V=-2/0/+2°九点，归一面积1020 mm²。新增显式copySourcePreparation配置及原/副本源设置审计；源分析光线数是ObjectPickup，副本转Fixed后设置、回读，主模型pickup保持原样。
- 最终`runs/rx-fov/260927-07/`九点completed，累计追迹27.656 s；原模型身份/dirty/采集字段/源设置与solve/磁盘SHA256核对不变，副本关闭、cleanupErrors为空。3081恢复原配置，未调用GLM或改变主模型/全局环境。
- 中心(H0,V0)面积归一效率：转镜70.614%、Rx入口33.017%、SPAD11.749%；SPAD原始通量4.9933 µW、源功率效率4.9933%。H+10/V0为0.2005%，H-10/V0为8.3524%，不对称需后续核查照明/遮挡/光路；十万条单种子小网格仅证明工作流，不构成收敛或完整FOV性能验收。
- 16项专项测试通过（新增source pickup副本准备边界）；最终包清单哈希核验通过，真实HTML桌面渲染已检查。03为原发光状态预检失败、04为首次通过预检、05为副本source solve兼容失败但主模型未变、06为补齐solve指纹的通过预检；全部保留，不冒充成功。探测诊断保存在artifacts/rx-instance2。


## 工作台显式保存（2026-09-27，已接入、模拟验证）

- 顶栏“保存到Zemax”保存当前绑定模型；连接弹窗“保存此模型”保存探测候选，保存本身不切换绑定。按用户要求点击即授权，不二次确认；普通刷新/探测/绑定仍不保存。
- 保存前核对绑定、实例、SystemID和revision，先备份磁盘旧文件再Save；回读NeedsSave/模型身份/导出字段并记录SHA256，已保存则不重复写盘。保存与采集互斥，复用光学排他锁；持久请求回执避免重复执行，不确定结果不自动重试。
- 单次保存记录使用runs/model-save短run与report.md，保留备份、配置和审计。未命名/原文件不存在时要求在Zemax先另存为，不隐式决定保存路径。
- 13项保存专项测试、最终112项Python/74项Node、DOM冒烟与项目检查通过；Tabbit验证两个按钮、点击才保存、失败保留、候选保存不绑定与实例改变失效。工作台插件0.5.0及后端已重载。真实活动模型Save留给用户点击，本轮未覆盖其磁盘文件，不声称真实保存实测。
- 证据runs/save-ui/260927-01/report.html；授权边界已加入AGENTS，完整说明见docs/guides/shared-workbench.md。快照实际读内存，未实现dirty时改读磁盘ZMX的回退。

## Rx收光效率FOV扫描Skill（2026-09-27，已移植、离线验证）

- 新增`optdsh-rx-collection-efficiency`，只读理解N02同名能力后适配：H/V笛卡尔网格、转镜/Rx/SPAD积分通量、源功率效率、面积归一效率及入口/转镜比值。旧对象号、1020 mm²与角度映射不作为当前模型事实。
- 包内YAML与确定性执行器支持离线plan、只读dry-run、独立CopySystem执行；模型/revision及检查指纹防过期、专家确认、与Tx共用排他锁、逐点回读、失败保留和主模型审计。不会保存或改写主模型；其他非零分析光线阻塞，避免单源效率被污染。
- 15项针对测试通过，全Python回归98项通过；项目/Skill格式检查通过。官方DSH FileSystemSkillProvider独立探针实际发现并读取三个业务Skill，新MCP工作流路由离线调用通过。未重启在用DSH；其已运行MCP工具目录的新枚举待重载验证，未做GLM真实触发或Zemax追迹。
- CLI离线计划`runs/rx-fov/260927-01/`；9点合成报告`runs/rx-fov/260927-02/`，两包清单哈希全部验证。Tabbit 1440/390双页验证无整页溢出，配置折叠可开合，已查看桌面热力表截图；诊断在`artifacts/rx-scan-port/`。
- 使用与差异：[移植说明](../docs/workflows/rx-collection-efficiency.md)。真实宿主API兼容性、目标模型映射、pickup传播与收敛待实际任务中inspect和专家确认；本次没有修改隔壁项目、活动模型或本机持久环境。


## 显式连接与模型切换（2026-09-27，真实实例2已实测）

- 顶部新增连接弹窗：按实例只读探测当前文件，5分钟内显式确认后重新校验、采集并原子保存本机绑定，无需手改expectedFile或重启。单服务共享绑定，连接/确认/刷新互斥；其他窗口的旧候选拒绝，不污染最新成功快照。
- 模型改变清空选择与筛选、适配视野；草稿文字保留、旧引用标记过期并拒绝发送。绑定提示可见；下次显式提交携带activeModel与切换说明进入官方消息，取消旧隐式引用。断开光学后端仍可继续无对象的一般讨论；没有自动唤醒Agent或迁移旧公差配置。
- 最终98项Python及74项Node测试、DOM冒烟/项目检查通过（包含工作区其他并行改动的现有测试）；Tabbit合成A/B模型验证探测不提交、实例改变失效、失败回退、成功切换、选择清空及草稿旧引用拦截。实际Host代理传参和官方prompt内容使用隔离夹具验证，未调用GLM。
- 根因已定位为实例不匹配：实例1返回NotAuthorized，用户新开的模型在实例2。Tabbit实测实例2探测→显式确认→92对象快照→6/6裁剪；再次刷新成功，配置持久保存instance=2与目标路径，ZMX磁盘SHA256不变。报错改为提示核对目标窗口Instance Number，不再断言许可证不支持。桥接及工作台插件0.4.0已重载；验收与截图见runs/model-switch/260927-01/report.html，使用入口见docs/guides/shared-workbench.md。
- 顺带修复stop-optics仍请求已退役聊天接口410的问题；停止光学后端不取消官方DSH聊天，不修改Zemax。

## 原生 NSC 公差 API 冒烟（2026-09-27，合成模型已实测）

- 用户授权接口与合成小模型测试。Interactive Extension 连接当前90对象NSC模型成功；TDE原有一行TOFF。独立CopySystem重置为点光源+矩形探测器，使用NSDD(-10, Data=0)评价RMS X宽度，写入并回读TNPS(1,2,3)，探测器Z位置±1 mm；无补偿。
- 原生OpenTolerancing完成Sensitivity和3次Monte Carlo；名义4.37028615 mm，负/正端点4.32660815/4.41397096 mm。原生TXT、ZTD和ToleranceDataViewer摘要均已取得；最终证据`runs/nsc-tol/260927-05/`，13份清单文件SHA-256核对通过。3次MC仅测试接口，不支持良率统计结论。
- Python/.NET枚举别名：设置NONSEQMeritFunction后ToString可显示RMSSpotRadius；GetCriterionAt和原生报告确认实际为Merit Function。此版本OutputFile/TolDataFile采用文件名，由系统模型目录解析；完整路径试验虽Succeeded=True却缺少产物，故不能仅靠成功标志验收。
- 原系统ID、采集字段/TDE/MFE目标权重、NeedsSave及磁盘SHA-256前后相同；副本已关闭，只读3081已恢复。没有保存或修改主模型，没有正式Tx/Rx公差或6D补偿，尚未接入产品Skill执行器。报告HTML内容由公共生成器生成，未做本轮浏览器视觉验收。
- 01—03保留失败调试记录；04仅工具状态成功、未取得结果文件，不能作为完整成功证据；05为最终通过记录。执行脚本随最终run保存。

## DSH原生视觉专家（2026-09-27，已实测）

- 同一份visual-designer源定义新增DSH第四分发目标：官方Standard副本Preset、展示元数据和委派persona；默认仍Standard。项目启动器在新进程启动前同步，版本/冲突保护保留。
- `plugins/optdsh-experts`接入原生spawn提供方、`expert_visual_designer`和`expert_resource`；专家会话用于完整设计，主Agent可委派一次性前台子专家并接收最终结果。子专家继承父模型及原生工具，没有新增工具白名单；光学工作台额外限制已按用户指示撤销，原生权限审批及光学执行器约束继续有效。
- 真实glm-5.3-flash：独立专家约17秒、最终主子委派约43秒，专家及子专家均实际调用参考读取与原生read，回读package.json正确。父/子请求均可见read/write/edit，未实际执行写入或连接Zemax。Tabbit确认专家名称、子代理入口及返回正文；重启后Preset、会话恢复和子历史可读。
- 初始直接采用官方委派工具description/prompt参数时，GLM重复description导致JSON不闭合；两次取消保留记录。最终以单task参数适配官方ctx.subagents.start，保持官方循环和生命周期，未切模型。16项Python分发测试、11项Node相关测试、项目/Skill检查通过。
- 证据与离线HTML：`runs/experts/260927-01/`。未验证像素理解或设计质量；子回答把资源返回字段resource误称为name，父回答照转，报告已注明此模型事实性瑕疵。一次性子Agent不提供持久团队会话控制。
- 使用与更新：[专家指南](../docs/guides/custom-agents.md)。


## 工作台与官方会话权限等价（2026-09-27）

- 按用户授权撤销工作台绑定Agent的额外工具白名单和tools/pre-execute拦截；继承官方Standard的工具、文件权限、审批与其他已配置插件。只追加光学基础指令，不替代官方权限机制。工作台插件0.3.0。
- 创建/恢复/绑定路径统一安装指引；对象上下文、公差Skill、基础指令、AGENTS及现行文档已取消“工作台不能使用Shell/副本CLI”的笼统限制。光学MCP查询仍只读，Tx执行保留授权、模型身份/revision、独占连接、CopySystem、回读和恢复；旧headless聊天入口保持停用。
- Tx独占预检检查其他宿主作业，不要求正在编排的共享聊天本身空闲。画板系统提示明确只约束画板编辑，不误禁其他已授权分析流程。
- 7项相关Node、5项Tx Python回归和项目检查通过；实际工作台插件隔离夹具覆盖恢复、现有会话绑定、重复绑定、新建会话，工具/权限保持，且不注册额外工具前后拦截。
- 重载前检查22个项目会话均无运行任务；DSH已重载，认证HTTP200。随后补改的画板系统提示尚未重载：发现1个运行中会话，间隔20秒复核仍忙，因此未打断；该文案待空闲重载，主工具权限修改已在此前重载中加载。未更改官方审批策略、未执行Zemax公差或GLM Shell端到端试跑。下方旧阶段“只读会话白名单”描述属于历史，现行权限以本节为准。

## 开发视觉专家（2026-09-27）

- 已从 AgentTyvate visual-designer 0.4.2 移植源定义、五类/12张参考图库和三宿主分发系统，本项目适配版0.4.3；增加光学事实、版本、面板/WebGL性能及报告规范。源项目未修改。
- 开发维护Skill位于 `.agents/development-skills/expert-distribute`，通过AGENTS入口读取；不进入DSH产品业务Skill目录。源定义与本项目偏好独立保存；生成文件与分发收据Git忽略，克隆后需分发。
- 已分发并回读校验：Codex 0.157.0、OpenCode 1.17.14、Claude Code 2.1.205；OpenCode `agent list --pure` 已发现 visual-designer (subagent)。Codex/Claude原生角色加载及三宿主真实设计调用待验证；Claude `agents --json`只列后台会话，不能作为角色发现证据。
- 15项分发生命周期/YAML测试、Skill格式检查、项目检查与本次文件diff检查通过。全仓diff检查另发现并发修改的planning/ROADMAP.md第29行尾空白，本轮未改该文件。覆盖幂等、备份、冲突保护、资源哈希、偏好不外发、YAML选择和非法配置拒绝。没有模型推理、Zemax连接或全局环境修改。
- 使用入口：[开发专家指南](../docs/guides/custom-agents.md)。


## 固定视图默认朝向（2026-09-27，已实测）

- 按用户指定：XY为X右/Y上，XZ为Z右/X上，YZ为Z右/Y上；相应从+Z/+Y/−X观察，保持右手系，不改变模型坐标或几何。
- 反向保持屏幕上方向，切换投影面恢复默认朝向和0°；45°CW/CCW保留。7项相关Node测试、DOM冒烟和项目检查通过；Tabbit实际页面逐面验证方向标、切换和旋转，停留默认YZ。
- 仅前端相机调整，不触发Zemax采集或写入，不合并其他在途Skill变更；说明见docs/guides/panel-resizing.md。

## 报告分级与光学模板（2026-09-27）

- 用户要求落实：十分简单任务可Markdown，复杂任务必须HTML；HTML先研究背景与目标，再Setup重点条件、结果解释和证据后续。配置原文/完整参数默认折叠，不用JSON替代专业摘要。
- 只读借鉴AgentTyvate测试报告的米白/深绿、统一字体和章节分段，重新实现光学报告生成器reporting.py及内嵌report.css。固定合成参考docs/templates/optics-report.html，说明docs/guides/optical-reporting.md；AGENTS、运行包规范、Skill与导航同步。
- RunBundle支持明确simple任务的report.md，复杂任务保持HTML，多工况拒绝MD。清单记录实际报告路径和渲染器哈希；旧run不重写。Tx保持多工况HTML，离线基线增加任务背景元数据。
- 57项Python测试通过，覆盖正文顺序、原始配置折叠、Markdown分级、转义/可移动证据与哈希。Tabbit 1440/390宽度无整页溢出，导航及配置展开/折叠实测；最终合成run为runs/report-style/260927-02，证据链接与哈希检查通过。
- 本次仅报告生成与视觉验证，未连接Zemax追迹；模板中的数据明确合成。Tyvate项目及历史报告未修改。

## 辅助Skill归位与Harness入口（2026-09-27）

- 用户确认只保留业务Skill。expert-collaboration迁为config/optical-agent-instructions.md，绑定光学会话通过agent.ctx.systemPrompt.section自动加载；普通未绑定会话不注入。创建/恢复/后绑定均接线，重复绑定不重复注册。
- optics-contract迁为docs/architecture/optics-contract-review.md；model-baseline迁为docs/guides/model-baseline.md。AGENTS、docs导航、画板引用及旧调用方已更新；旧expert-collaboration工具别名只为历史调用兼容，已从新工具枚举隐藏。
- 新增docs/guides/harness-customization.md，按固定DSH 0.1.5-rc.3本地源码和官方文档说明section/context、pre-step、工具管线、turn-stopping及命令Hook兼容桥的边界。没有启用额外Hook兼容桥。
- 55项Python与7项相关Node测试通过；其中实际Cordis/SystemPrompt组装验证作用域隔离及dispose清理。项目链接检查通过。工作台插件0.2.1，项目会话空闲后重载，认证HTTP200；未做GLM行为验收或Zemax追迹。

## 公差Skill统一入口（2026-09-27）

- 按用户原意保留唯一`optdsh-assembly-tolerance`：先识别Tx/Rx/两者和任务阶段，再加载包内独立流程；不明确则询问，单侧缺项不阻塞另一侧。原Tx/Rx独立SKILL已迁入references，不再参与技能发现。
- Tx脚本迁至`scripts/run_tx_pilot.py`，原算法和副本边界不变；包内有Tx试跑、Tx装调预检、Rx预检三份YAML样例，预检支持YAML/旧JSON及显式scope。历史run与本机配置未改写。
- 现行工作台接入固定资源的只读workflow_guide，按意图返回独立分支、配置与预检；旧tx/rx名称仅作兼容工具别名，未恢复旧headless聊天路径。工作台插件0.2.0，无通用文件/Shell或公差执行权限。
- 55项Python、5项工作台Node测试及项目/Skill检查通过；DSH官方FileSystemSkillProvider独立探针仅发现一个公差Skill，真实MCP stdio列工具和Tx分支调用通过。新路径Tx plan命令生成runs/tx/260927-01，Rx YAML预检只报告Rx及公共缺项。
- 确认项目会话空闲后重载DSH，认证HTTP200。未执行Zemax追迹，未进行GLM真实对话路由验收；完整6D补偿、Monte Carlo及Rx执行仍未实现。

## v0.1.1布尔模块加载修复（2026-09-26，已实测）

- 已定位并修正官方Host迁移后的Worker绝对根路径404，使用相对viewer模块URL，不更改认证/CSP或布尔算法。
- Tabbit当前真实模型6/6裁剪成功（约71ms Worker单批）；Worker/Manifold JS/WASM均200，OBJ58显示3680三角面的闭合近似裁切。实体与固定视图已检查。
- 新增部署前缀下的Worker创建分支回归；CSG 6项测试及DOM冒烟通过。根项目版本、锁文件、README、CHANGELOG更新为0.1.1；对应提交与标签以Git记录为准。

## v0.1.0版本基线（2026-09-26）

- 根版本由初始化占位0.0.1升为0.1.0，版本规则、CHANGELOG、锁文件一致性检查及工作台版本显示已建立。DSH依赖保持0.1.5-rc.3；内部画板插件0.5.0、工作台插件0.1.0独立维护。
- 本轮离线回归：64项Node、54项Python、工作台DOM冒烟和项目检查通过；实际认证HTTP已显示v0.1.0。main和附注标签v0.1.0已推送并核验，基线提交bc14897。
- 用户随后报告布尔计算模块加载失败、Web裁剪未生效；单元布尔计算通过不能证明当前浏览器模块加载。版本基线同步后优先专项修复，不将此问题写成已解决。

## 分隔线交互修复（2026-09-26，已实测）

- 根据用户实机反馈和Blender/VS Code公开资料，手动拖动改为边界驱动：相邻两栏优先一增一减，碰到最小尺寸才向外传递，替换此前全局同比再分配。窗口变化仍保存比例，聊天可扩大半屏。
- 上下拖动原先DOM已变化但WebGL未同步：补上内部view-surface尺寸观察并按帧合并重绘；移除多余30px相对偏移。横线8px与扩大命中区、拖动高亮、Esc撤销、双击复位与键盘微调已接入。
- Tabbit实测list左边界-80px时右边界及远端面板不动；上下+100px后真实GPU viewport与DOM吻合；刷新恢复/Esc/50:50/半屏验证通过。17项相关Node及DOM冒烟通过，报告runs/splitters/260926-01/report.html。
- 规则入口docs/guides/panel-resizing.md，AGENTS已路由；没有新增依赖、改变模型或声称长期性能验证。

## Figma修改意见1前端优化（2026-09-26，已实测）

- 读取用户Figma 31:104及文字意见，并结合后续澄清：四栏同比缩放，默认43.89/10.22/14.53/31.35%；取消会话650px上限，比例保存为v5，旧像素宽度不继承。双击分隔线或Home恢复默认。
- 消息13px、角色左右气泡与分色、输入区独立底色；移除可见身份行和空气泡，支持安全的加粗/行内代码。画板结构化内容及旧提交默认折叠，普通代码不误隐藏。
- Tabbit验证1280/1920/3440宽度默认比例一致、无横向溢出；3440屏会话可拖到1720px，刷新持久保存；深浅主题和折叠实测。17项相关Node测试、实际应用DOM冒烟与项目检查通过。最后截图和报告在runs/ui-feedback/260926-01。
- 本轮只改前端与静态资源映射，未发送模型请求、未写Zemax；用户Figma意见页保留不动。

## 本期01/02/03同会话工作台（2026-09-26，已实测）

- 新增optdsh-workbench薄插件：官方3080认证页面承载原光学布局，精简会话直接使用官方sessionController；同会话完整Web跳转与返回、画板按需弹窗已实现。3081保持独立只读后端，旧AgentJobs/CanvasBridge入口410，不再从工作台启动headless进程。
- 完整Web与弹窗复用web/shared/canvas-bridge.js及唯一BoardStore。修复实机发现的官方消息slot延迟注册，镜片/画板技术内容默认折叠；精简消息过滤系统注入。对绑定会话保留只读光学＋画板工具白名单。
- 3轮glm-5.3-flash真实验收在同session完成：真实OBJ7/11只读查询、官方API追问、画板提交；重复ID去重、内容冲突、旧版本拒绝。Host真实重启后绑定与消息恢复；模型文件SHA256不变。
- Tabbit两标签实际验证工作台、完整会话跳转、真实WebGL、共享画板、默认折叠和弹窗关闭后未发送说明保留。53项Node、54项Python及真实应用DOM冒烟通过；后者WebGL为stub，不能替代Tabbit证据。
- 新入口scripts/open-optics.ps1（支持-NoBrowser）；使用与边界见docs/guides/shared-workbench.md，run报告在runs/workbench/260926-01。当前精简会话约1.8秒更新已记录消息，非逐token流式；多窗口画板冲突保留原机制，长期并发/内存表现待观察。04下翻区未实施。

## 四张草稿的实施范围（2026-09-26，设计梳理）

- 本期准备做01工作台主界面、02其画板弹窗，并完成03与现有完整DSH同会话衔接；不重建完整DSH界面。04下翻分析区留待后续。
- Figma四图标题、说明和排布已同步，入口见docs/guides/figma-workbench.md。仅整理范围，未启动产品改造。

## 05A画板按需弹窗（2026-09-26，设计）

- 用户确认画板不常驻工作台；05A右栏改为默认精简会话，新增临时画板弹窗草稿。快速绘图/标注/发送在弹窗，建议与多轮修改主要进入同一DSH完整会话。
- Figma 17:54更新，25:87为弹窗状态，05C缩略稿同步；截图检查通过，设计说明同步。仅设计，未改运行产品。
- 用户已撤销“不使用Tabbit”约束，AGENTS与共享环境已更新偏好；系统关联只读仍显示MSEdgeHTM，未自动更改设置。

## 双页面同会话草稿（2026-09-26，设计）

- 用户指出两端空间紧张，修订为独立光学工作台＋精简会话/画板，按钮新开官方完整Web同会话；不将工作台挤入官方侧栏。
- Figma原文件新增05A/B/C三张可编辑草稿并截图检查，原04保留。下翻区建议只放作业、报告、参数对比；草稿各窗口独立，已保存画板与提交共享，版本冲突不静默覆盖。
- 双页面共享Host/controller、画板模块与同session为待实现目标；未改运行服务或Zemax。见[设计方案](../docs/architecture/workbench-convergence.md)及[Figma入口](../docs/guides/figma-workbench.md)。

## DSH与光学工作台架构复盘（2026-09-26，仅审查）

- 已核对本地实现：光学Python服务＋MCP、自制3081聊天/headless runner，与官方3080画板插件分属两条交互链；共用DSH库和存储不等于同一会话控制器。3081旧画板和受限工具不能自动继承官方画板v4。
- 建议让官方DSH统一会话和交互，以光学插件复用现有几何/桥接；先同聊天对象引用＋画板闭环，再布局迁移、旧适配退役和仿真作业整合。详见[复盘](../docs/architecture/workbench-convergence.md)。
- 未改运行代码、未重启服务、未连接宿主或调用模型。上游声明支持页签/会话输入与引用；完整布局和光学同会话集成仍待探针，不宣称已接入。

## 画板v4协作体验（2026-09-26）

- 自然语言与画板技术数据分离，聊天默认灰色折叠；兼容旧提交，不改历史。拒绝建议可展开修改意见并发回原聊天，交付幂等。
- 解除用户/绑定图形限制：移动原图与文字/连线联动，删除维护引用；不再用复制代替移动。项目专项Skill同步，全局Skill未改。
- 28项Node、116项Canvas逻辑测试与构建通过；GLM实测100px移动→拒绝反馈→150px重新提案并应用，原ID保持。证据artifacts/canvas-v4-validation。
- 浏览器自动验证被工具策略中止（URL无法可靠识别）；折叠和反馈下拉的实机视觉仍待验。详见[画板说明](../docs/architecture/canvas-session-boards.md)。

## Tx YAML落实与docs分类（2026-09-26）

- Tx现支持安全YAML读取，Skill包内样例为config/tx-pilot.example.yaml；本机config/tx-pilot.local.yaml由旧JSON等价转换，产品workflow_guide优先读YAML。原始YAML及规范化参数随run归档，旧JSON显式输入兼容。
- 54项Python测试通过；配置Python环境实际plan通过，占位符execute在连接Zemax之前拒绝。校验重复键、非有限数值、安全解析、样例等价和原始字节冻结；没有重新追迹。
- 26份docs按governance/architecture/guides/workflows/research/archive分类，decisions保留；总入口docs/README.md。历史草案标记归档，AGENTS增加工作内容到必读约束表，README缩短为核心入口。链接与代码引用已同步，项目检查通过。
- 依赖声明requirements-config.txt固定PyYAML==6.0.3，使用既有环境中的同版本；未安装依赖或修改N02/全局规范。以下条目为此前阶段历史，当前状态以上述更新为准。

## 配置型Skill范式（2026-09-26）

- 用户指定：配置优先YAML，Skill包内必须附带YAML样例。已写入铁律OPT-14，同步AGENTS与运行包规范。
- 本次为规范更新；既有Tx等JSON执行入口尚未迁移，不将YAML规范当作已经支持的运行能力。历史run保持原格式。

## 公共运行包与HTML报告（2026-09-26）

- 已只读核对N02运行规范、公共分配器、Study配置和HTML报告实现，将共性要求提升至AGENTS、项目铁律OPT-13与docs/governance/run-bundles.md。
- 公共run_bundle模块原子分配runs/<workflow>/YYMMDD-NN；执行前冻结配置、离线HTML、JSON证据和文件SHA-256。Tx plan/execute与离线baseline入口已接入；失败也保存报告。服务诊断保留artifacts，未改全局规则或N02。
- 上一轮Tx证据校验复制到runs/tx/260926-01，报告report.html；配置从旧result.json提取，原始文件在original，旧路径保留。本次未重新追迹，旧运行环境/代码版本未保存的部分明确unknown。
- 51项Python测试通过；Tx计划/校验失败与合成离线指标CLI实测。报告在系统默认Edge引擎完成桌面渲染检查。新包装器未另做Zemax实跑，原光学执行逻辑未修改。

## Tx独立公差功能测试（2026-09-26，已实测）

- 新增独立Tx/Rx Skill与scope预检；对象序号、扰动范围、采样/指标都从配置读取。Tx配置config/tx-pilot.local.json，示例examples/tx-pilot.example.json。Rx规格不阻塞Tx。
- 内存CopySystem上完成18工况：两片镜片各X/Y±10μm、倾斜X/Y±0.01°，首尾名义重复；四die采样，其他源禁用。分析光线数Pickup在副本中改Fixed；镜片参考链重挂与所有非目标世界位姿检查通过。
- 试跑定义：探测器局部X径向投影角、7%–93%能量区间。名义H-D86全角1.172°，扰动范围1.172–1.176°；差异仅一个H像素0.004°，不作敏感度排名或制造结论。
- 主模型回读、dirty与磁盘SHA256不变，副本关闭无错误，3081桥接恢复。结果artifacts/tx-tolerance/pilot-03/report.md及result.json。48项Python测试与项目检查通过；后补的进程锁/异常审计保护尚未用故障注入完整覆盖。
- 下一步先做像素/光线/物理探测口径收敛；6D补偿、Monte Carlo与Rx追迹未实现。本次直接运行确定性工具，不代表GLM自主执行已验证。

## 官方画板反向编辑v3（2026-09-26）

- 用户实机确认v2会话打开/绘图/发送成功，新增需求为Agent操作画板。
- 原生canvas_read/canvas_propose_edit已接入；元素级建议稿、只读预览、显式应用/拒绝、版本冲突保护和原生撤销接线完成。
- 项目专项`.agents/skills/optdsh-canvas/SKILL.md`已由真实GLM发现调用；本机主目录通用Skill未改。GLM实际生成蓝色圆形＋文字，接口验证原图保留/应用幂等/跨会话拒绝通过。
- 19项Node、116项Canvas UI逻辑测试与构建通过；新建议稿UI实际点击与Undo仍待用户验收。详见[会话画板v3说明](../docs/architecture/canvas-session-boards.md)，证据artifacts/canvas-edit-validation。

## 官方会话画板v2（2026-09-26）

- 已取代固定会话投递探针：标题栏画板入口、一聊天一board、嵌入编辑模式、版本保存/历史快照、官方prompt复用Agent、稳定requestId去重和显式确认处理。
- 11项Node边界测试、Canvas原有113项UI逻辑测试和构建通过；两个新聊天三次真实GLM投递（A1/B1/A2）通过，未认证401、跨board拒绝、重复入队保护通过。
- 独立Canvas项目/旧提交保留，3081适配未迁移；默认Edge视觉/实际点击仍待验（CUA不可用）。详见[使用与验证](../docs/architecture/canvas-session-boards.md)。下方分期1与审查为历史记录。

## 装调Skill：对象映射与离线指标（2026-09-26）

- 本轮桥接重新启动且真实采集90对象成功。候选清单区分源/探测器/镜片/布尔结果与构造体，保留modelId/revision；机械镜筒归属仍未确认。
- 用户确认Tx四颗die（当前OBJ2–5）作为一个刚体整体6D耦合。已保存本机config/assembly-tolerance.local.json；Rx1(940)/Rx2(905)优先级待答，候选SPAD为61/76。
- 公差Skill新增baseline.py与数据定义参考，确定性内核支持显式定义的带权角域86%区间及矩形H/V，报告二维矩形实际能量比例；不隐式套用相邻项目90%口径。
- 8项新增测试与合成CSV命令通过，全部44项Python测试通过；Skill格式和项目检查通过。产物artifacts/tolerance-baseline。
- 没有执行追迹/模型扰动/补偿优化，也未取得有新追迹与版本证明的真实名义D86或Rx尺寸；目前交付为基线准备，不是公差分析结果。

## AgentCanvas 初稿审查（2026-09-26）

- 当前官方插件仅验证固定会话的一次投递；当前聊天绑定、绑定画板入口、独立board身份和连续提交尚不满足使用闭环。
- 源码核对及隔离探针发现静态目标会话、重复resume、去重状态未读取、提前complete和取消边界问题；详细证据及修订验收见[初稿审查](../docs/archive/agent-canvas-review.md)。本次只检查和记录，未改运行实现。

## AgentCanvas 接入分期1已实现（2026-09-26）

- 插件 `plugins/optdsh-agent-canvas`：Host 侧桥接（Canvas 定向 wait→resume 会话→followup→回答→complete 回执）+ Client 侧右侧"画板"页签（iframe 载入 4173，失败提示改用系统浏览器）。经 `config/dsh.local-policy.yml` 以 `--patch` insert 本地路径装载，无需 pnpm/plugin add；client 模块由 host Loader entries 自动进浏览器 boot 图。
- 端到端探针通过：合成提交（两矩形+箭头+文字）→ 桥接领取 → session-c5b27910 内 turn completed（glm-5.3-flash 复述元素结构正确）→ Canvas complete 回执、inbox 清空、state.json 幂等记录、消息持久化到 storages/session_projcache。证据 `.runtime/agent-canvas-bridge/state.json`。
- 关键实现事实：空会话 resume 后 followup 会因 prompt 组装缺 `{{model}}` 报错，需按 `config/optics-model.json` 在 resume 时 installModelSelection；消息主体持久化在 storages/session_projcache（jsonl.zstd 仅会话头）；Loader entry 相对路径相对 patch 文件目录解析且不支持目录导入。
- 待验收：浏览器视觉（右侧画板页签+iframe 实际渲染、聊天中消息可见）；绑定状态显示、忙时排队、崩溃恢复与去重为分期2。

## 持续会话、画板与领域Skill（2026-09-26）

- 3081工作台已复用官方DSH AgentRegistry.resume；连续三轮GLM测试使用同一个sessionId，能记住前轮定义的“耦合基准A”。服务持久索引保存会话/任务，异常中断不自动重发。
- 新增“新会话/会话选择/连接画板/确认画板已处理”；Canvas接收者绑定指定聊天，不扫共享待处理箱。合成定向提交实际进入第三轮并得到正确上下文回答；原画板scene内容比对一致（autosave导致revision计数增长，不能用整包哈希误判）。
- 新建optdsh-expert-collaboration和optdsh-assembly-tolerance项目Skill；GLM实际调用workflow_guide读取两者，预检明确未具备公差执行器。
- 用户确认：Tx H-D86全角、光源6D补偿；Rx矩形H/V光斑、SPAD 6D补偿；先装镜筒再耦合。作为近期优先业务，参数模板与预检已交付；未运行公差仿真。
- 36项Python、19项JS及真实应用DOM冒烟通过；三轮结束后再次采集90对象成功，dirty保持、ZMX哈希不变。证据artifacts/conversation-validation。
- 仍未完成：官方Web原生嵌入、画板图片像素/回画、失败会话自动修复、离线旧提交重投与默认浏览器完整交互验收。当前Canvas模式是3081会话绑定，区别于下方官方Web设计提案。

## Agent Canvas 接入提案（2026-09-26，设计）

- 已只读核对固定版本DSH的右侧页签/会话输入声明与AgentCanvas提交、等待、目标选择和版本接口；建议原生薄插件＋独立画板服务。
- 先验证官方Web同聊天接收画板，再做Agent建议稿与光学标注；离线定向领取、崩溃去重、嵌入模式与图片能力为明确验收项。
- 详见[接入设计](../docs/archive/agent-canvas-integration.md)。未安装插件、修改相邻项目、连接/领取画板提交或调用模型。

## 最新连接复核（2026-09-26 06:21，本地时间）

- 用户提出待验证假设：进程嵌套及子进程退出可能影响API连接。后续正常测试遇到复现时对齐DSH/MCP退出、采集worker连接/退出、extension实例与LicenseStatus的时间，不先认定根因、不为此另开定时监控。当前DSH查询经HTTP读桥接快照，ZOS采集worker由桥接刷新独立启动，两条路径须分开核查。

- 用户确认API已连接后，显式refresh成功，90对象、2.39秒、两次读取一致、dirty前后均true；revision未变化。
- zai/glm-5.3-flash多引用OBJ59/60实际查询完成，16.6秒，返回20mm原点距离、世界ΔZ=-20mm、局部ΔZ=+20mm，工具无错误且结果未过期。
- 证据artifacts/layout-v4-validation/glm-multi-recheck.json；这是本次恢复，不宣称间歇性NotAuthorized原因已解决。

## 方案04已实现（2026-09-26）

- 用户实机反馈字号偏小后，主要文字调整为13–14px，按钮/辅助文字约12px；保留28px单行对象列表与紧凑顶栏，未缩放3D画面。

- 双视图四列、固定投影反向与CW/CCW 45°、全局XYZ方向标及原点轴开关；多选对象嵌入指令草稿、服务端版本校验。
- 用户执行中补充已纳入：28px列表单行编号/备注、超长省略/悬停全文；顶部合并紧凑入口、低频选项折叠，分类筛选放列表内；大列表窗口化。
- 32项Python+19项JS通过，实际应用DOM模块冒烟通过（WebGL替身，不是浏览器视觉验证）。HTTP资源200，源ZMX哈希未变。
- 重启桥接时宿主再次NotAuthorized，保留历史快照且拒绝新查询；本轮没有新的GLM真实多选验收。默认浏览器入口已打开，CUA无法连接Edge，未改用Tabbit。
- 默认浏览器排版/IME/Undo/GPU与真实多对象查询待验；详见docs/guides/workbench-v4.md和artifacts/layout-v4-validation。

## 运行入口修复（2026-09-26）

- 用户报告DSH打不开时，3080进程已停止，3081正常；直接start-dsh启动成功，停止原因未定位。
- open-dsh现在可在服务停止时启动；start-dsh重复运行复用同端口且身份匹配的进程。新增可双击open-dsh.cmd。
- 当前PowerShell与Windows PowerShell 5认证HTTP200；浏览器实际加载官方DSH界面，GLM-5.3-Flash显示正常。未修改模型凭据或占用其他服务端口。

## 已确定

- 目标为光学专家与 Agent 协作工作台；对话、空间交互和监控分离。
- 官方 DSH Web + Standard + 可替换非顶尖模型起步；不绑定 GLM，Creator 辅助开发。
- 独立光学服务持有模型访问，DSH 只做适配；先只读后写入。
- 个人模型试验与公司部署分开；公司允许开源框架，其模型与数据出口受控。

## 本轮交付

- M0 项目骨架、Codex AGENTS.md、项目铁律手册、两个项目级 skills、架构与接口草案。
- 合成场景及专家提交样例、无凭据配置样例、上游候选版本快照。
- 本地结构检查脚本；Git 已初始化为 main，尚无提交和远端。

## 初始化验证

- `python scripts/check_project.py`：通过，文档/skill 相对链接、JSON 与合成样例对象引用一致。
- 两个 skills 均通过 skill-creator 的 `quick_validate.py` 格式检查。
- 模型约束已由 GLM 唯一通道修正为非顶尖模型原则，示例 model 留空，待选择。
- Codex `/init` 对应的 AGENTS.md 入口已手工按背景建立；未执行交互式命令，未改全局 Codex 配置。
- 新 skill 在新任务的自动发现尚未实测，不把文件校验视为运行宿主已加载。

## 未实现/未验证

- DSH Web、三家文件工具调用及GLM的M2真实对象查询已实测；多模态与复杂任务仍未验证。
- Zemax只读连接/90对象快照/版本校验已实现；精确几何、跨版本永久身份、写入/恢复尚未实现。
- 独立Three.js近似几何/四视图查看器已实现；M3内嵌交互和AgentCanvas适配未实现。
- 已测 GLM-5.3-Flash、MiniMax-M2.7-highspeed、deepseek-flash；不等于已完成选型，图片能力未验证。
- 无远端仓库，无发布或推送。

## M1 第一步已完成：运行环境

- 项目本地安装 @deepseek-ai/dsh@0.1.5-rc.3，package-lock.json 固定依赖；Node 24.13.1。
- 独立 DSH_HOME 为 .runtime/dsh，只监听 127.0.0.1:3080；官方令牌认证保留。
- start/open/status/stop 脚本齐备；启动、认证 HTTP 200、停止/重启和实际浏览器页面通过验证。
- 通过官方 browse 目录选择器添加本项目，标准模式可见；模型引导选择稍后配置，无推理请求。
- OTel DISABLED、DeepSeek session log contribution关闭；完整网络出口审计尚未做。
- 运行说明：docs/guides/local-runtime.md；截图和检查证据：artifacts/dsh-host/（本地，Git忽略）。

## M1 三家接入冒烟测试（2026-09-26）

- 用户完成三家凭据录入后，Agent 经官方Web分别运行同一合成只读任务；实际请求头确认路由，三次均 completed。
- MiniMax/DeepSeek坐标与间距正确；GLM把Z平移误读为X。三家均识别合成数据与版本冲突。
- MiniMax实际加载 optdsh-optics-contract：当前DSH已发现该项目skill；不能再将项目skills一概视作只供Codex读取。
- 仅一次/模型，不能作质量排名；图像/仿真/写操作及长期稳定性未验证。
- 报告与证据：artifacts/model-smoke-20260926/report.md 和 results.json（本地，Git忽略）。用户原有hello会话保留，默认模型恢复MiniMax。

## M2 前置设计记录（下方 MVP 已执行）

- 用户指定相邻opt-assist为优先复用来源；先只读检查实际目录E:/Proj-2026-N02_opt-assist、连接封装/对象导出/注册表/手册。见docs/research/opt-assist-reuse.md。当时只补文档与方案，后续MVP实现见下方。
- M2先复用确定性读取，补world transform、revision与对象身份；M3采用场景组件＋DSH薄插件，先最小槽位与点选提交，再接真实快照。

1. 将合成场景的坐标解析与版本检查实现为确定性只读工具，避免依赖模型读取矩阵后自行推算。
2. 用本轮同一案例比较工具化后的效果，再确定首个光学助手基线。
3. 公司接入与完整网络出口另验；小样本成功不代表所有部署策略已经验证。
4. 图片输入独立验证；失败时保持结构化文本路径。

以上为M2实施前的安排；当前交付与剩余边界以下方MVP记录为准。

## M2 MVP 已实现（2026-09-26）

- 复用opt-assist连接封装，extension1只读连接本项目0926-optdsh-test模型；90对象GetMatrix成功，保留dirty=true。
- src/optdsh_optics提供两次一致读取、快照内容revision、保守对象引用和确定性相对位置；30秒worker超时、busy/断连错误处理，不自动fallback。
- 3081独立查看页面：搜索/过滤/点选、原点坐标轴与参考关系、主体/全景/聚焦、相对计算、复制提问草稿。不是实体曲面或光线渲染。
- DSH新增optics MCP四工具；首次新增启动组合未热加载，空闲重启后真实GLM验收成功：OBJ59→60世界ΔZ=-20 mm、局部ΔZ=+20 mm、原点距离20 mm。
- 12项离线测试通过；认证/跨源/无写路由/过期引用、刷新一致性、14个Ref0对象平移、磁盘ZMX不变及dirty状态保持已核验。源项目未修改。
- 证据：artifacts/m2-validation；使用说明：docs/architecture/m2-optics-bridge.md。
- 下一步由用户检查查看器与真实模型的物理意义，再推进M3内嵌场景及显式发送；复杂实体几何和长期稳定性仍待验收。

## M2.1 首版已实现（2026-09-26）

- Three.js 0.186.1项目依赖锁定、本地提供资源；单场景四相机，支持空间/XY/XZ/YZ、最大化、联动聚焦和正交缩放同步。
- 只读提取typed尺寸字段；90对象中63个参数化近似形状，15个参考对象，12个非比例标记。6个布尔结果不做CSG，复合镜片为名义代理。
- 分类配色、手动显示分类、分类显隐/隔离、半透明/实体/线框；不改变模型材料和可见性。
- 支持自定义鼠标组合键和聚焦键，冲突检查、localStorage保存、输入框排除。默认Shift+左键平移，正交相机锁定旋转。
- 19项Python+7项JS测试通过；Tabbit交互验证通过，旧20mm查询仍正常。证据 artifacts/m2-1-validation，使用说明 docs/guides/viewer-controls.md。
- 源模型ZMX哈希与升级前一致；没有保存或写入模型。用户可继续评估近似外观，M3嵌入与复杂几何后续实施。

## M2.2 布尔裁切（2026-09-26）

- 实现A&B镜片/矩形体封闭近似裁切，首操作数坐标系到结果对象姿态，补Clear外机械平边；不支持表达式/倾角明确保留标记。
- Manifold 3.5.4本地WASM Worker，32项几何缓存，旧revision结果丢弃，20秒超时；颜色/相机不重算，刷新保留视角。
- 既有真实快照6组全部生成裁切网格，浏览器Worker约81ms冷批次；缓存0.1ms，单镜片变化约7.1ms。加速60轮测试非一小时实机验收。
- 当前重新连接Zemax返回LicenseStatus=NotAuthorized，未修改授权配置；同模型旧快照可恢复显示，查询仍拒绝STALE_SNAPSHOT。实时编辑回读和专家逐对象对照待验证。
- 使用与证据：[布尔裁切](../docs/architecture/boolean-cuts.md)、[开源调研](../docs/research/frontend-reuse-research.md)、artifacts/m2-2-validation。
- 用户决定暂不增加自动采集；1次参数修改/min是持续性能基线，已写入AGENTS及铁律。

## M3 只读工作台 MVP（2026-09-26）

- 用户确认Zemax仍打开后重新连接，采集90对象成功，revision与M2.2一致，dirty保持；此前NotAuthorized原因未定位，不声称永久修复许可问题。
- 紧凑深浅主题、左右/底部可调整面板；回答与运行记录分开，同屏查看。
- 显式点选发送经DSH headless项目适配返回回答，独立单次会话；不是官方Web内嵌，也不是连续多轮聊天。
- 模型仅看到无参数selection_context工具，后端绑定modelId/revision/objectId/比较目标，代码计算关系；真实工具目录验收只有这一项。
- 旧版本拒绝、请求幂等、单任务、跨源/认证、取消已验；30项Python、13项JS通过。证据artifacts/m3-validation。
- 用户新增近期策略：只测试glm-5.3-flash，不再测试MiniMax表现；config/optics-model.json和项目DSH默认同步，GLM实测结果单列。
- 初期MiniMax接线样例曾误缩写ID并猜测过期；已用绑定工具消除此类参数输入。仍需评价GLM答案质量，不能把completed当所有解释正确。
- 下一步：用户体验当前布局和只读问答；官方Web内嵌、真实写提案、完整非球面和长期性能后续推进。

- GLM实测补充：两次zai/glm-5.3-flash完成，裁切核心关系正确（仍有解释边界问题）、20mm相对位置正确；用时25.6/20.7秒，不推广为质量全面通过。
