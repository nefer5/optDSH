# 开发自定义专家

optDSH 复用 AgentTyvate 的专家源定义与四宿主分发机制。当前只启用视觉设计专家，用于工作台、报告、页面的设计或实际画面评估；同时支持开发宿主与DSH原生专家会话/子Agent；没有新增模型供应商或光学写工具。

## 使用

在本项目聊天中说：

> 调用 visual-designer 视觉设计专家，检查当前光学工作台的视觉层级，先只评估，不改代码。

设计任务可说：

> 请 visual-designer 帮我改进报告视觉，先简短确认需求，需要比较时先给 A/B 小样，选定后再完整实现。

宿主必须支持并发现自定义角色。已有聊天未加载时，在本项目新建会话后核对。若当前宿主没有按角色名调用的工具，主 Agent 明确读取源定义、偏好与参考，按同一规范执行并说明是主 Agent 执行，不能谎称调用了原生专家。

## 文件与同步

[专家中心](../../.agents/README.md)是入口；[源规范](../../.agents/experts/visual-designer/instructions.md)是唯一正文。角色不固定模型、不提高权限；产品 GLM 测试约束仍有效。保留开工简短沟通、低成本小样、选定后完整实施和实际画面验证。既有用户指示与本任务已确认需求优先，不重复询问。

```powershell
python .agents/development-skills/expert-distribute/scripts/distribute.py
python .agents/development-skills/expert-distribute/scripts/distribute.py --apply
python .agents/development-skills/expert-distribute/scripts/distribute.py --check
```

YAML 选择入口及样例见[分发 Skill](../../.agents/development-skills/expert-distribute/SKILL.md)。默认四宿主，支持 only/exclude。脚本拒绝未核对的 CLI 版本、手工漂移、非托管同名文件和越界资源。更新前备份及 SHA-256 收据在 `.agents/.distribution`。这是开发配置维护；正式专家分析与报告仍使用公共 run 包。

开发维护 Skill 独立于 `.agents/skills`，通过 AGENTS.md 显式入口读取，不新增 DSH 业务 Skill。四个宿主的生成角色文件及公共参考副本本地生成且 Git 忽略，克隆后需重新分发。没有全局配置修改或自动同步源项目。

## 来源与验证边界

来源：本机 AgentTyvate 的 visual-designer 0.4.2、分发脚本及白名单图库；本项目适配版 0.4.3 增加光学事实、坐标与版本、面板、WebGL、性能和报告约束。源项目的私人网站偏好未复制为本项目默认。

Codex 格式按[官方自定义 Agent 文档](https://learn.chatgpt.com/docs/agent-configuration/subagents)核对：项目 `.codex/agents/*.toml` 必填 name、description、developer_instructions。OpenCode/Claude 保留源项目已核对的格式，分发时核对实际 CLI 版本。文件分发、宿主发现、真实设计调用分别验收，当前状态见 planning/STATUS.md。


## DSH 网页使用

**直接找专家**：官方Web新建会话，在模式选择器选择“视觉设计专家”（`visual-designer`），再提出设计或评估任务。它以固定版本Standard为基础，保留原生文件、Shell、Skills等能力和宿主权限审批。默认模式仍是Standard；已有产生消息的会话不能切换Preset。

**让主Agent找专家**：在Standard或光学工作台聊天中说“调用视觉设计专家，帮我……”。项目插件向本项目普通会话注入原生 `expert_visual_designer` 委派工具；固定视觉角色，继承父模型，不自动fallback。当前采用 `spawn` 的一次性前台调用，主Agent等结果后转述；子Agent没有父历史，主Agent须提供任务与已确认偏好。需要后续迭代时再次委派，并传递前轮结论。它不是持久化团队聊天入口。

工具和审批沿用DSH；用户已明确撤销光学工作台额外白名单，本接入也不对专家子Agent施加额外工具白名单。原生spawn子会话的审批生命周期遵从上游，无法现场请求批准的动作可能被原生策略拒绝，不提升权限绕过。Zemax版本检查、专家确认、回读与恢复仍是执行器事实约束。

`expert_resource` 可按资源白名单读取图库、偏好及有限项目规范，不需要把图库全部注入上下文。PNG默认返回元数据，`mode=image` 才经官方attachment服务返回真实图片；必须另验模型图像能力，文字验收不能证明像素理解。完整专家会话也可用原生文件工具处理任务材料。子Agent拥有独立会话和画板，修改主画板时应返回方案给父Agent在主会话应用，不能假定两个画板相同。

## DSH 实现与更新

- 生成目录 `.agents/dsh-presets/visual-designer`：`agent.cordis.yml`保留官方Standard工具组合，仅替换persona；`preset.yml`提供显示信息；`expert.json`供子Agent加载相同正文。
- 项目 `config/dsh.local-policy.yml` 注册Preset根目录与原生spawn实例；`plugins/optdsh-experts` 在属于本项目的主Agent作用域注册委派工具。其他项目不会得到本项目角色委派。
- 修改专家源后运行 `distribute.py --only dsh --apply`，再检查 `--check`。`start-dsh.ps1`在实际新进程启动前同步；同进程复用不会重载旧角色。空闲后重载Host以使插件正文更新，并使用新会话验证；正在进行的会话不自动迁移Preset。
- 新增依赖为零，保持DSH 0.1.5-rc.3；生成文件/本机收据Git忽略，源定义/插件/适配器跟随仓库。

依据：[官方Preset](https://github.com/deepseek-ai/deepseek-harness/blob/dsh-v0.1.5-rc.3/packages/preset/agent-presets/README.md) · [官方委派工具配置](https://github.com/deepseek-ai/deepseek-harness/blob/dsh-v0.1.5-rc.3/packages/subagent/tool-subagent/README.md)。

接线实测中GLM曾对官方委派工具的description/prompt双字段生成重复description，导致调用未闭合。项目工具因此只暴露一个task参数，内部使用官方ctx.subagents.start、spawn提供方及原生结果/取消生命周期；显示标签由适配器固定。此为参数适配，不是自建Agent循环。
