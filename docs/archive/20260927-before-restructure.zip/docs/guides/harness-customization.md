# DSH Harness定制入口

本项目固定`@deepseek-ai/dsh@0.1.5-rc.3`；2026-09-27核对安装包实现、类型声明和同标签官方文档。以下入口属于该版本，不假定master接口稳定。

## 从哪里改

- 装配入口：[config/dsh.local-policy.yml](../../config/dsh.local-policy.yml)经启动器`--patch`挂载本地插件；保留Standard和官方agent loop。
- 产品适配：[plugins/optdsh-workbench/lib/index.js](../../plugins/optdsh-workbench/lib/index.js)，现已有sessionController、按会话基础指令（不改变Standard工具权限）、HTTP/UI和上下文提交。
- 产品常驻规则：[config/optical-agent-instructions.md](../../config/optical-agent-instructions.md)，经[agent-policy.js](../../plugins/optdsh-workbench/lib/agent-policy.js)注册到绑定Agent自己的`agent.ctx.systemPrompt.section`，创建/恢复/后绑定都处理；宿主加载时读取，编辑后重载宿主。
- 光学能力：[scripts/optics-mcp.py](../../scripts/optics-mcp.py)及`src/optdsh_optics/`。DSH插件做适配，版本/权限/数据计算由确定性服务保障。
- 业务流程：仅装调公差与画板Skill；开发评测看[模型基线](model-baseline.md)，契约评审看[开发指南](../architecture/optics-contract-review.md)。

## 上下文放在哪里

| 内容 | 入口 | 时机与边界 |
|---|---|---|
| 稳定产品规则 | `agent.ctx.systemPrompt.section({name,order,text})` | 注册一次，每次step组装；本项目光学规则只属于已绑定会话 |
| 会变化的运行状态摘要 | `systemPrompt.context({name,order,text: context => ...})` | 每步求值，框架生成带持久记录的user-role运行上下文快照；回调读已有状态，不在里面直接连接Zemax/追迹 |
| 用户本轮选中对象和问题 | 官方`sessionController.prompt()`的content | 只在显式提交后一起入队，先校验modelId/revision；现有`promptContent()`实现此路径 |
| 步骤准入/输入检查 | `agent/pre-step` waterfall | 可拒绝或替换该step的输入批次；不要丢弃next()的消息与startsRequestSeries等字段 |
| 外部结果通知 | `agent.inject()` | 添入下一被接纳step，不唤醒空闲Agent；`steer()`会唤醒并走下一step，`followup()`排下一turn |
| 大型报告/数组 | 工具结果摘要＋run产物引用 | 不把完整光线数组反复注入提示词；先按业务请求取需要的数据 |

step是一次模型请求及其工具处理周期；一个用户turn可能包含多个step。稳定规则每步组装不等于每步都向历史追加一条相同消息。

本地`dsh-agent-loop/lib/index.js`的`preStep()`顺序是：领取inbox → systemPrompt.assemble → 生成动态context → agent/pre-step → 接纳step。随后解析请求路由/prepareCall并提交模型可见记录。因而在pre-step里临时注册section不能假定会影响同一次已组装的请求；稳定section应提前注册。

工具循环：模型请求 → `tools/pre-execute` → 单调guard → `tools/execute` → `tools/post-execute` → 结果定稿/`tools/result` → 下一step或`agent/turn-stopping` → turn结束。

## Hook开发选什么

原生插件通过`export const inject=[...]`声明服务依赖，在`apply(ctx)`内用`ctx.on(...)`注册事件/中间件；资源用`ctx.effect`绑定生命周期。普通emit观察事件、serial事件和waterfall中间件不是同一种返回协议，应看安装包`lib/types/*.d.ts`，不要凭名称猜签名。

| 需求 | 扩展点 |
|---|---|
| 新建/恢复Agent后设置作用域 | `agent/created`；需要发布前配置则使用创建时setup/preset组合 |
| 每步接纳前校验输入 | `agent/pre-step` |
| 工具权限/专家确认 | `tools/pre-execute`；不可被后续插件放宽的同步约束用`ctx.tools.guard()`；真正写入口仍要服务端再校验 |
| 工具结果检查、补充上下文 | `tools/post-execute` |
| 结果审计/UI通知 | 只读观察`tools/result`或持久`session/event`，不把显示流当最终事实 |
| 判断是否允许自然结束 | `agent/turn-stopping`；只做与当前任务相关的有限检查，避免无限steer/阻塞交付 |

DSH也安装了`dsh-hooks-codex`和`dsh-hooks-claude-code`命令Hook兼容桥，底层仍映射这些原生事件；不是照搬另一宿主所有语义。例如当前Codex桥`configPath`为进程级、加载时读取，工具前只支持阻断，不支持批准或重写。检查项目patch未显式配置这两个桥；安装包存在不等于本项目启用。已有命令Hook迁移可考虑兼容桥，新optDSH能力优先原生插件。

## 本项目下一步建议

沿现有薄插件加小功能：稳定协作规则已接入；动态状态摘要、分析作业通知、版本化写提案仍需逐项实现及验收。不替换agent loop，不恢复旧headless聊天路径，不把鼠标草稿变成自动提示。工具执行完成、Agent回答完成、仿真作业结束分别建模。

验证先测作用域隔离、版本拒绝、取消及事件顺序，再用glm-5.3-flash做真实对话；配置完成、宿主加载、模型按规则行动分别报告。当前基础规则迁移未做GLM模型行为验收。

## 固定版本依据

- [System Prompt](https://github.com/deepseek-ai/deepseek-harness/blob/dsh-v0.1.5-rc.3/packages/core/system-prompt/README.md)
- [Agent API与生命周期](https://github.com/deepseek-ai/deepseek-harness/blob/dsh-v0.1.5-rc.3/packages/core/agent/README.md)
- [工具执行管线](https://github.com/deepseek-ai/deepseek-harness/blob/dsh-v0.1.5-rc.3/packages/core/tools/README.md)

精确签名以本地`node_modules/@deepseek-ai/dsh-agent/lib/types/runtime-types.d.ts`、`dsh-system-prompt/lib/types/index.d.ts`、`dsh-tools/lib/types/`及两个hooks包的类型/实现为准；不要直接修改node_modules。

## 项目专家扩展

[自定义专家](custom-agents.md)已接入官方Agent Preset和Subagent：同一份源定义经分发生成专家会话与委派persona，保留Standard默认；项目插件只注册原生工具并加载资源，不重写Agent循环。
