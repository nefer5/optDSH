# Rx收光效率FOV扫描移植

业务入口：[optdsh-rx-collection-efficiency](../../.agents/skills/optdsh-rx-collection-efficiency/SKILL.md)。本流程与装调公差独立：扫描视场而非镜片制造误差，不进行优化或6D补偿。

## 来源与理解

2026-09-27只读检查相邻`E:/Proj-2026-N02_opt-assist`，HEAD `9f8d7a3727dc59d81c9314e9fc34a4df12ad8ff1`。
来源为`.agents/skills/lidar-rx-collection-efficiency-scan/`的SKILL、config、两个example.py与intent-and-elements参考。

原算法：H/V控制网格→模型内pickup传播→每点清探测器并NSC追迹→所有观测面的total_flux→源功率效率、面积归一效率、Rx入口/转镜比值。面积归一基准是P_source×A_max/A_source，不能与SPAD PDE、脉冲能量混淆。旧记录为87对象模型，当前项目模型已有变化，旧对象号/最大面积不迁为有效绑定。

## 适配取舍

| 原实现 | optDSH实现 |
|---|---|
| 示例脚本依赖旧仓库根自动查找 | 本项目独立计算模块；仅连接器经bridge配置只读复用N02 |
| configs与旧Study路径、run-local脚本 | config/*.example.yaml；公共RunBundle一次分配，代码哈希和配置冻结 |
| 原系统备份并直接写入，finally恢复initial | 独立CopySystem；关闭副本并回读审计主模型，绝不Save主模型 |
| 固定对象语义、pickup与角度公式 | 精确对象身份、pickup、仿射FOV换算全部配置化 |
| 同时写range与deltas时静默优先 | 拒绝歧义、非有限值、重复点、超预算网格 |
| total_hits/mean/peak也可进入效率列 | 仅Detector Rectangle的total_flux计算效率 |
| 其他光源仅warning、IgnoreErrors默认true | 默认其他非零分析光线阻塞；显式确认后可用copySourcePreparation在副本固定光线数pickup并切换发光源；IgnoreErrors=false且检查Succeeded |
| 旧报告与matplotlib可选PNG | 公共背景/Setup报告，加内嵌二维热力表与逐点表，不新增依赖 |

执行先核对modelId/revision，再核对dry-run的inspectionDigest；后者覆盖源、控制、pickup、detector尺寸/采样与其他源。它不等于完整模型序列化；运行时必须避免人工并发编辑。

## 使用与状态

命令、配置和停止条件统一维护在Skill。离线计划无需许可证；dry-run/execute使用配置指定的隔离Python、NSC毫米模型及Interactive Extension。
产品可通过原生项目Skill发现或`workflow_guide(name='rx-collection-efficiency')`读取；该MCP入口仍只读，正式执行经Standard Shell运行副本CLI。

离线验收覆盖配置、指标、扫描矩阵、模拟宿主边界、CLI计划与报告。后续用户已授权实例2真实模型试跑，并确认仅副本切换Tx/回波源；真实结果与已知限制见[当前状态](../../planning/STATUS.md)。未调用GLM，光线数收敛与完整视场性能仍需专项验证。
