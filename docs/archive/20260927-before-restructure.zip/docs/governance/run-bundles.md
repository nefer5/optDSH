# 运行包规范

适用于本项目所有产生正式分析、评测或仿真交付的Skill和脚本。仅打印帮助、交互式预检与服务日志不强制创建run。公共实现为`src/optdsh_optics/run_bundle.py`，不依赖Zemax或DSH。

## 目录与命名

```text
runs/<workflow>/YYMMDD-NN/
  manifest.json        身份、时间、状态、来源、文件SHA-256
  config/input.yaml    原始输入配置，保留原格式（旧JSON输入为input.json）
  config/resolved.json 本次实际使用的完整参数
  config/runtime.json  必要运行环境字段（如适用，不含凭据）
  plan.json            工况计划（如适用）
  report.html          复杂任务必需；简单任务可用report.md
  result.json          机器读结果，失败也保留
  *.npz                大数组；按实际需要采用子目录
```

workflow使用tx、rx、baseline等短名。日期取分配时本地日期，序号至少两位、同一父目录递增，排他创建、不覆盖。开始只分配一次，所有阶段接收同一目录；不再嵌套时间戳或重复workflow。完整时间含时区，任务描述写manifest，不拼进目录。仓库相对路径按UTF-16计数，>180警告，>220拒绝，包含文件名。

当前无需照搬N02完整STUDYS层级；将来确有多个独立研究时，可以用`studies/<study>/runs/<workflow>/YYMMDD-NN/`，仍沿用同一公共分配器。

## 配置与证据

- 配置型Skill遵循[铁律OPT-14](project-rules.md#opt-14-skill配置范式)：优先YAML，Skill包内附带YAML样例。run保留输入原文和扩展名；规范化resolved快照可用JSON。Tx入口已支持YAML及旧JSON；run保留原始扩展名，实际参数统一保存为resolved.json。

- 先冻结配置，再执行；执行器消费run中resolved配置。后续修改项目config不改变旧run。
- 文件输入同时保存原始配置和已展开默认值/覆盖值的resolved配置；只有CLI参数的工具也保存完整解析参数。清晰区分业务配置与运行环境，不能只记录外部文件路径。
- 输入数据能随包携带时保存副本并核对哈希；商业模型/大型外部依赖可只保留身份、版本、哈希和获取条件，明确包不独立可复现。活动模型的dirty内存不等于磁盘版本。
- 凭据不随包复制。运行环境采用允许字段清单，记录凭据名称或位置，不保存值。run默认Git忽略，不等于允许存放秘密。
- 完整执行代码以提交版本或代码文件哈希记录；哈希用于识别，不代表已打包全部依赖。缺失信息写unknown，不用当前代码/配置补成历史事实。
- 成功、计划、失败、未完成、历史整理分开标记。失败时保留已冻结配置、已完成工况与错误。强制杀进程可能留下created/running，不能当成功。
- 完成时manifest列出包内文件大小和SHA-256（不递归哈希manifest自身）。完成后不覆盖；更改参数重跑创建新run，续跑仅在工作流明确支持时使用。

## 报告分级与内容

- **十分简单的小任务可用Markdown**：如单项参数核对、简单配置检查、无多工况/图表的短结论。使用`report.md`说明任务、关键条件、结果、限制和证据即可，不为小任务强做HTML。
- **较复杂任务必须HTML**：如多工况公差、参数扫描、补偿前后对比、多步骤试验、模型评测、需要图表/多份证据才能解释的分析。复杂度由任务内容决定，不靠字数或耗时；Tx多工况和正式模型评测按复杂任务处理。拿不准时用HTML。
- 正式运行的配置冻结、结果、manifest及SHA-256要求不因Markdown而省略。manifest.report指向实际交付文件。交互式一句预检仍可仅输出JSON，不强制新建run。

HTML正文顺序必须是：**研究背景与目标 → Setup → 结果与解释 → 限制、证据与下一步**。开头可列身份、日期、实测/模拟/计划状态，但不以结果数字或配置原文代替研究背景。

1. 背景：为什么做、研究对象、要回答什么问题；说明范围及判定标准。未提供的业务条件明确待补，不能编造。
2. Setup：以参数表/摘要呈现所用模型及输入文件、版本、关键对象、坐标与单位、扰动/补偿、光源/波长、光线数/随机种子、探测面/采样、指标定义等与本任务相关的条件。只挑关键项，不把config原文直接贴在正文；缺失记未记录，不能用当前配置补历史事实。
3. 结果：关键指标、工况对照和必要图表；随后解释物理意义、分辨率/采样限制和是否达到目标。失败保留已完成部分，不用completed替代正确性判断。
4. 证据与后续：结果数据、配置快照、manifest和校验链接；明确下一步。**原始配置、完整解析参数、运行环境详情和完整结果JSON默认折叠**，正文不以JSON块代替专业解释。

HTML须UTF-8、离线无CDN、桌面/窄屏可读，随整个run移动仍可用（内部相对链接）；图表标单位、基准、统计口径。用户文本转义，原始JSON/CSV/NPZ保留为证据。样式与内容扩展规则见[光学报告指南](../guides/optical-reporting.md)，视觉参考为[合成光学样例](../templates/optics-report.html)。

公共实现`RunBundle.create(..., complexity='complex')`默认HTML；明确简单任务可用`complexity='simple'`生成Markdown，也可显式要求HTML。复杂任务拒绝Markdown，多工况结果不能以简单Markdown输出。`config.report`记录背景/目标/重点条件，`result.report`记录解释/后续；字段见报告指南。

## 当前入口

- Tx：`python .agents/skills/optdsh-assembly-tolerance/scripts/run_tx_pilot.py config/tx-pilot.local.yaml`，默认产生plan包；`--execute`才实际运行。`--runs-root`可指定项目内父目录，程序分配短ID。
- 离线指标/对象清单：公共装调Skill的`baseline.py`，默认写`runs/baseline/`，输入副本随包。
- 历史Tx整理：`python scripts/import-tx-run.py artifacts/tx-tolerance/pilot-03`，校验复制到新run，保留旧证据；从旧result提取当时配置，不追迹、不冒充新执行。历史包缺失runtime/执行代码时保持未知。

## 参考N02的范围

已核对N02的AGENTS“Run路径铁律”、`docs/architecture/study-workflow-guide.md`、`src/auto_zemax/runtime/run_paths.py`及Study的`run_context.py`和HTML报告生成器。采用一次分配、短ID、配置随包、路径预算与离线HTML。未照搬旧报告脚本的“排序取最新目录”，入口必须显式绑定本次run；未修改N02，也未移植其自动保存活动模型或远端发布规则。
