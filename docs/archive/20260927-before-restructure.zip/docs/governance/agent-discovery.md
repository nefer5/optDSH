# 分层与发现入口

本页为2026-09-27对照N02 AGENTS的现行入口盘点。根[AGENTS](../../AGENTS.md)保持必读规则与路由，本文说明职责与发现方式；实际进展只在[STATUS](../../planning/STATUS.md)维护。

## 从任务到入口

| 层级 | 权威入口 | 放什么、如何发现 |
|---|---|---|
| 项目规则 | 根AGENTS.md、docs/governance/ | 开始读README与STATUS，按AGENTS任务表进入专题；不每轮通读所有docs |
| 产品Agent指令 | config/optical-agent-instructions.md | 光学会话作用域注入；规则修改不代表已运行会话自动重载，须区别磁盘与实际加载 |
| 产品业务Skill | .agents/skills/*/SKILL.md | 原生FileSystemSkillProvider扫描；用户点名或意图匹配后完整读取对应Skill，再按需读reference/config |
| 开发维护Skill | .agents/development-skills/ | 仅开发宿主使用，通过AGENTS/专家指南发现，不混入产品业务目录 |
| 专家源与适配 | .agents/experts/、.agents/distribution.json | 源定义与分发入口见[专家中心](../../.agents/README.md)；宿主生成目录不是另一份权威源 |
| 确定性光学逻辑 | src/optdsh_optics/ | 连接适配、数据契约、计算、报告、run分配；不得依赖具体run或从产品提示词推断光学事实 |
| 启动与协议适配 | scripts/、plugins/、web/ | CLI/服务入口、DSH工具事件、浏览器表现；光学计算不藏在插件中 |
| 长期说明 | docs/ | 架构/操作/研究/规范；archive仅历史，不用旧方案覆盖现行入口 |
| 当前交付 | planning/ | 进度、验证与待办；不把运行完成当作光学正确性 |
| 正式运行 | runs/ | 输入、结果、报告和哈希按[run规范](run-bundles.md)，不把历史run改成新实验 |
| 临时诊断 | artifacts/ | 日志、一次性探针和失败调试；已有temp仅按原用途保留，新正式结果不得默认写temp |
| 泛化经验 | [.experience/README.md](../../.experience/README.md) | 现象→原因→处理→边界→证据；开始相关排障前先搜索引，成功后按需更新 |
| 本机配置与运行态 | config/*.local.*、.runtime/ | 模型绑定/认证/进程状态；不作为代码示例，不进Git，不复制凭据到run或经验库 |

## 已有业务能力与边界

| Skill | 当前入口与边界 |
|---|---|
| [装调公差](../../.agents/skills/optdsh-assembly-tolerance/SKILL.md) | 先区分Tx/Rx；Tx副本功能试跑，Rx预检/离线指标，完整6D优化未实现 |
| [官方画板](../../.agents/skills/optdsh-canvas/SKILL.md) | 原生canvas读取/建议稿；与独立AgentCanvas分开 |
| [Rx收光效率](../../.agents/skills/optdsh-rx-collection-efficiency/SKILL.md) | H/V扫描、只读预检与副本追迹；使用模型版本绑定和确认后的配置 |

当前没有N02的`skill-lab/`、`.agents/registries/skills.yaml`或独立Skill SemVer体系；不凭文档建立“已安装/稳定”的假状态。业务目录即当前可发现资源，试验代码留在artifacts，晋升Skill需配置、执行器和验证证据。项目版本仍以[版本规范](versioning.md)为准；若未来确需技能注册表，应连同发现/校验工具一起实现。

## 晋升与同步

- 重复的确定性动作进入src；可复用的领域交互/判断进入业务Skill；开发分发进入development-skills；有因果链的经验进入.experience。
- 不移植N02的STUDYS目录、旧对象号、强制全局依赖或默认子Agent委派策略；本项目现用runs/workflow短目录，委派遵循当前宿主与用户授权。
- 入口新增/迁移同时更新AGENTS任务表、docs导航与真实调用方，检查旧链接和产品发现。文件存在、独立Provider发现、运行中DSH加载、真实模型验证必须分开报告。
- 对外提交前沿用本项目版本与数据出口检查，不自动安装相邻项目的发布Skill，不因整理规则而推送或重启服务。
