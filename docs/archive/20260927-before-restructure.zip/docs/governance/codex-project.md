# Codex 项目初始化

## 已落地

Codex 的 `/init` 用于生成 AGENTS.md。这里依据真实项目背景直接创建并整理了相同的规则入口，没有声称执行过交互式 `/init` 命令，也不再用通用模板覆盖它。

- 根 [AGENTS.md](../../AGENTS.md)：自动发现的项目指令入口。
- [项目铁律手册](project-rules.md)：规则理由与验收边界，按需读取。
- `.agents/skills/`：项目级 skills，随仓库维护，不安装到用户全局目录。
- [当前状态](../../planning/STATUS.md)：交接入口；普通进度不写共享环境记忆。

## 业务技能与开发指南

产品和开发Agent都会发现项目Skill，因此这里只保留按业务触发的[装调公差](../../.agents/skills/optdsh-assembly-tolerance/SKILL.md)和[画板操作](../../.agents/skills/optdsh-canvas/SKILL.md)。

- 产品常驻行为：[光学Agent基础指令](../../config/optical-agent-instructions.md)，由工作台插件只注入已绑定光学会话，无需调用Skill。
- 开发契约：[契约评审指南](../architecture/optics-contract-review.md)及[数据契约](../architecture/contracts.md)，身份/版本校验仍由服务代码与测试实施。
- 开发评测：[模型基线指南](../guides/model-baseline.md)，不进入产品技能目录。
- 插件及Hook：[Harness定制](../guides/harness-customization.md)。

2026-09-27从三个旧Skill迁移；历史会话中的Skill调用保留为历史证据，不代表当前目录仍有该入口。

## 加载与验证边界

文件已创建并进行格式/链接验证，不等于当前已启动任务的技能目录一定即时刷新。后续 Codex 任务从本仓库打开；若技能列表未出现，重启会话后检查，或显式指定文件路径读取。无需为项目初始化修改全局配置或创建空 `.codex/config.toml`。

## 官方依据

- [AGENTS.md](https://learn.chatgpt.com/docs/agent-configuration/agents-md)
- [项目 skills](https://learn.chatgpt.com/docs/build-skills)
- [开发命令与 /init](https://learn.chatgpt.com/docs/developer-commands?surface=cli)
